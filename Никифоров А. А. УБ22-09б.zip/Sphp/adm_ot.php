<?php
global $name;
require_once('bd.php');

$title = $name;
ob_start();
?>
<div class="con0">
    <h3 class="t">Администратор</h3>
    <div class='ys'>

        <?php
        session_start();
        $User = $_SESSION['User'];
        $login = $_SESSION['login'];
        $password = $_SESSION['password'];
        $mail = $_SESSION['mail'];
        $n = $_SESSION['n'];
        $n1 = $_SESSION['n1'];
        echo "<form action='adm_p_o.php' method='post' class='ysp'>
            <div class='con1'>
            <input class='pole' type='text' placeholder='Имя' name='n' value='$n'>
            <input class='pole' type='text' placeholder='Фамилия' name='n1' value='$n1'>
            <input class='pole' type='text' placeholder='Почта' name='mail' value='$mail'>
            <input class='pole' type='text' placeholder='Логин' name='login' value='$login'>
            <input class='pole' type='password' placeholder='Пароль' name='password' value='$password'>
           </div>
              <div class='levo'>
                        <div class='ysbox1'> 
                         <button class='btn' type='submit'>Сохранить</button>
                           <button class='btn' type='button' onclick='logout()'>Выход</button> 
                           </div>  
                            </div> 
                            <div class='levo'>
                            <div class='ysbox1'> 
                               <button class='btn' type='button' onclick='site()'>Настройки сайта</button>  
                               <button class='btn' type='button' onclick='adm_ys()'>Все услуги</button>      
                               <button class='btn' type='button' onclick='adm_ot0()'>Пользователи</button>                 
                            </div> 
                            </div>  
                              </form>

                         
                  "?>

    </div>


</div>


<?php
global $conn;
require_once('bd.php');

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Запрос к базе данных
$sql = "SELECT History, s_dt, s_name, s_cost, s_n, s_n1, s_mail FROM history";
$result = $conn->query($sql);

// HTML код с вставленной таблицей в блоке 'ys'
$tableHTML = "<div class='ysp'>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px; /* Добавим немного отступа сверху для лучшего визуального восприятия */
        }
        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
    </style>
    <table>
        <tr>
            <th>№</th>
            <th>Дата/Время</th>
            <th>Услуга</th>
            <th>Стоимость</th>
            <th>Имя</th>
            <th>Фамилия</th>
            <th>Почта</th>
        </tr>";

// HTML код с вставленной таблицей


if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {


        $tableHTML .= "<tr>
        <td>" . $row["History"] . "</td>
        <td>" . $row["s_dt"] . "</td>
        <td>" . $row["s_name"] . "</td>
        <td>" . $row["s_cost"] . "</td>
        <td>" . $row["s_n"] . "</td>
        <td>" . $row["s_n1"] . "</td>
        <td>" . $row["s_mail"] . "</td>
        </tr>";
    }
} else {
    $tableHTML .= "<tr><td colspan='3'>No records found</td></tr>";
}

$tableHTML .= "</table>";

?>

<!-- HTML код с вставленной таблицей в блоке 'ys' -->
<div class="con0">
    <h3 class="t">Отчет</h3>
    <div class='ys'>
        <?php echo $tableHTML; ?>
    </div>
</div>
<div class="m0"> </div>



<?php $content = ob_get_clean(); ?>

<?php require_once('base.php'); ?>



