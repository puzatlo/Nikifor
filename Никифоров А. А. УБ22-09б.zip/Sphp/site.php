<?php
global $name;
require_once('bd.php');

$title = $name;
ob_start();
?>
<div class="con0">
    <h3 class="t">Администратор</h3>
    <div class='ys'>

        <?php
        session_start();
        $User = $_SESSION['User'];
        $login = $_SESSION['login'];
        $password = $_SESSION['password'];
        $mail = $_SESSION['mail'];
        $n = $_SESSION['n'];
        $n1 = $_SESSION['n1'];
        echo "<form action='adm_p_o.php' method='post' class='ysp'>
            <div class='con1'>
            <input class='pole' type='text' placeholder='Имя' name='n' value='$n'>
            <input class='pole' type='text' placeholder='Фамилия' name='n1' value='$n1'>
            <input class='pole' type='text' placeholder='Почта' name='mail' value='$mail'>
            <input class='pole' type='text' placeholder='Логин' name='login' value='$login'>
            <input class='pole' type='password' placeholder='Пароль' name='password' value='$password'>
           </div>
              <div class='levo'>
                        <div class='ysbox1'> 
                         <button class='btn' type='submit'>Сохранить</button>
                           <button class='btn' type='button' onclick='logout()'>Выход</button> 
                           </div>  
                            </div> 
                            <div class='levo'>
                            <div class='ysbox1'> 
                               <button class='btn' type='button' onclick='site0()'>Пользователи</button>  
                               <button class='btn' type='button' onclick='adm_ys()'>Все услуги</button>      
                               <button class='btn' type='button' onclick='adm_ot()'>Отчет</button>                 
                            </div> 
                            </div>  
                              </form>

                         
                  "?>

    </div>


</div>


<div class="con0">
    <h3 class="t">Сайт</h3>


    <?php
    global $conn;
    require_once('bd.php');

    $sql = "SELECT * FROM site";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            echo "<div class='ys'>
                     <form action='s.php' method='post' class='ysp' enctype='multipart/form-data'>
                     <div class='con1'>
                    <img src='img/{$row['logo']}' alt='Изображение' class='img' width='150' height='150'>
                    <input class='pole' type='text' placeholder='Название' name='name' value='{$row['name']}'>
                    <textarea class='pole' placeholder='Описание' name='description' rows='4' cols='50' >{$row['description']}</textarea>
                    <input class='pole' type='text' placeholder='Цвет' name='color' value='{$row['color']}'>
                    <input type='file' name='logo' accept='image/*'>     
  </div>
            <div class='levo'>
                <div class='ysbox1'>
                    <button class='btn' type='submit'>Заменить</button>
                </div>
            </div>

                    </form>
                </div>";


        }
    }
    ?>



<div class="m0"> </div>



<?php $content = ob_get_clean(); ?>

<?php require_once('base.php'); ?>



