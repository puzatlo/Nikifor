<?php

global $conn;
require_once('bd.php');


$Ser = $_POST['Ser'];

// Запрос для выборки строки из таблицы history
$sqlSelectHistory = "DELETE FROM service WHERE Ser = '$Ser'";

$resultSelectHistory = $conn->query($sqlSelectHistory);

echo "<script>window.location.href = 'adm_ys.php';</script>";



