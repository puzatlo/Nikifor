<?php
global $name;
require_once('bd.php');

$title = $name;

ob_start();
?>
    <form id="regForm" action="register.php" method="post">
        <div class="con1">
        <h3 class="t">Регистрация</h3>
        <input class="pole" type="text" placeholder="Имя" name="n">
        <input class="pole" type="text" placeholder="Фамилия" name="n1">
        <input class="pole" type="text" placeholder="Логин" name="login">
        <input class="pole" type="text" placeholder="Пароль" name="pass">
        <input class="pole" type="text" placeholder="Повторите пароль" name="repeatpass">
        <input class="pole" type="text" placeholder="Почта" name="mail">
        <button class="btn" type="submit">Зарегистироваться</button>
        <button class="btn" type="submit" onclick="reg()">Отмена</button>
        </div>
    </form>
    <div class="m0"> </div>
<?php $content = ob_get_clean(); ?>

<?php require_once('base.php'); ?>