<?php
global $conn;
require_once('bd.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $User = $_POST['User'];
    $n = $_POST['n'];
    $n1 = $_POST['n1'];
    $mail = $_POST['mail'];
    $login = $_POST['login'];
    $password = $_POST['password'];
    $adm = $_POST['adm'];

    // Здесь вам нужно выполнить SQL-запрос для обновления записи в таблице "Полные тексты"
    $sql = "UPDATE user SET n = '$n', n1 = '$n1', mail = '$mail', login = '$login', password = '$password', adm = '$adm' WHERE User = '$User'";
    // Выполнение запроса
    $result = mysqli_query($conn, $sql);
    echo "<script>window.location.href = 'adm.php';</script>";

}
