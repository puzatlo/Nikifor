<?php

global $conn;
require_once('bd.php');


$User = $_POST['User'];


$sqlSelectHistory = "DELETE FROM user WHERE User = '$User'";

$resultSelectHistory = $conn->query($sqlSelectHistory);

echo "<script>window.location.href = 'adm.php';</script>";



