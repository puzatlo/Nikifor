<?php
global $conn;

require_once('bd.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = $_POST['login'];
    $pass = $_POST['pass'];

    if (empty($login) || empty($pass)) {
        echo "<script>window.location.href = 'index.php';</script>";
    } else {
        $sql = "SELECT * FROM user WHERE login = '$login' AND password = '$pass'";
        $result = $conn -> query($sql);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $sql1 = "SELECT * FROM user WHERE User = '$row[User]'";
                $result1 = mysqli_query($conn, $sql1);
                if (mysqli_num_rows($result1) > 0) {
                    session_start();
                    $row = mysqli_fetch_assoc($result1);
                    $_SESSION['User'] = $row['User'];
                    $_SESSION['login'] = $row['login'];
                    $_SESSION['password'] = $row['password'];
                    $_SESSION['mail']  = $row['mail'];
                    $_SESSION['n'] = $row['n'];
                    $_SESSION['n1']  = $row['n1'];
                }
                if ($row['adm'] != 0){
                    echo "<script>window.location.href = 'user.php';</script>";
                } else {
                    echo "<script>window.location.href = 'adm.php';</script>";
                }
            }
        } else {
            echo "<script>window.location.href = 'index.php';</script>";
        }
    }
}


