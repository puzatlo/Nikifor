<?php

global $conn;
require_once('bd.php');

// Задайте значение History, которое вы ищете
$History = $_POST['History'];

// Запрос для выборки строки из таблицы history
$sqlSelectHistory = "DELETE FROM history WHERE History = '$History'";

$resultSelectHistory = $conn->query($sqlSelectHistory);

echo "<script>window.location.href = 'user_ys.php';</script>";



