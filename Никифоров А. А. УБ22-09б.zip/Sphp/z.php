<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Подключение к базе данных
    global $conn;
    require_once('bd.php');

    // Получаем значение из POST-запроса
    $s_Ser = $_POST['s_Ser'];
    $s_cost = $_POST['s_cost'];
    $s_name = $_POST['s_name'];
    session_start();
    $s_User = $_SESSION['User'];
    $s_mail = $_SESSION['mail'];
    $s_n = $_SESSION['n'];
    $s_n1 = $_SESSION['n1'];
    $s_dt =

    // Добавляем значение в таблицу history
    $sql = "INSERT INTO history (s_Ser, s_dt, s_name, s_cost, s_User, s_n, s_n1, s_mail) VALUES ('$s_Ser',  NOW(), '$s_name', '$s_cost', '$s_User', '$s_n', '$s_n1', '$s_mail')";
    $result = $conn->query($sql);

    echo "<script>window.location.href = 'user.php';</script>";
}
