<?php
global $name;
require_once('bd.php');

$title = $name;
ob_start();
?>
<div class="con0">
    <h3 class="t">Авторизация</h3>
<div class='ys'>
    <div class='ysbox1'>
<form id="loginForm" action="login.php" method="post">
    <div class="con1">

        <input class="pole" type="text" placeholder="Логин" name="login">
        <input class="pole" type="password" placeholder="Пароль" name="pass">
        <button type="submit" class="btn" name="action" value="login">Войти</button>
        <button type="button" class="btn" onclick="register()">Регистрация</button>
    </div>
</form>
</div>

    <div class='ysbox'>
        <?php
        global  $description;
        require_once('bd.php');
        echo '<h4>'.  $description .'</h4>'
        ?>
    </div>
</div>
</div>

<div class="con0">
<h3 class="t">Услуги</h3>

    <?php
    global $conn;
    require_once('bd.php');


    $sql = "SELECT * FROM service";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            echo "<div class='ys'>
                <div class='ysbox'>
                    <p>№ {$row['Ser']} </p>
                    <p>{$row['s_name']} </p>
                    <p>{$row['s_description']} </p>
                    <p>Стоимость: {$row['s_cost']}</p>
                    <div class='openModalBtn'><button class='btn'>Заказать {$row['Ser']} слугу</button></div>
                </div>";

            echo "<div class='ysbox1'>
                <div class='levo'>

                     <img src='img/{$row['s_picture']}' alt='Изображение' class='img' width='150' height='150'>
                </div>
            </div>";

            echo "</div>";
        }
    }
    ?>
</div>
<div class="m0"> </div>

<div class='modal' id='myModal'>
    <div class='modal-content'>
        <span class='close' id='closeModalBtn'></span>
        <p>Для заказа услуги необходимо авторизовааться!</p>
    </div>
</div>


<?php $content = ob_get_clean(); ?>

<?php require_once('base.php'); ?>


