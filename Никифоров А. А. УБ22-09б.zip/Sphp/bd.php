<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bd";
$conn = mysqli_connect($servername, $username, $password, $dbname);

if(!$conn){
    die("Connection Fialed". mysqli_connect_error());
}


// Выполняем SQL-запрос для получения первой строки из таблицы "site"
$sql0 = "SELECT name, description, logo FROM site LIMIT 1";
$result = mysqli_query($conn, $sql0);
// Проверяем, есть ли результат
if (mysqli_num_rows($result) > 0) {
    // Получаем ассоциативный массив с данными из первой строки
    $row = mysqli_fetch_assoc($result);
    // Присваиваем значения переменным
    $name = $row['name'];
    $description = $row['description'];
    $logo = $row['logo'];

}

