<?php
global $name;
require_once('bd.php');

$title = $name;
ob_start();
?>
<div class="con0">
    <h3 class="t">Администратор</h3>
    <div class='ys'>

        <?php
        session_start();
        $User = $_SESSION['User'];
        $login = $_SESSION['login'];
        $password = $_SESSION['password'];
        $mail = $_SESSION['mail'];
        $n = $_SESSION['n'];
        $n1 = $_SESSION['n1'];
        echo "<form action='adm_p_o.php' method='post' class='ysp'>
            <div class='con1'>
            <input class='pole' type='text' placeholder='Имя' name='n' value='$n'>
            <input class='pole' type='text' placeholder='Фамилия' name='n1' value='$n1'>
            <input class='pole' type='text' placeholder='Почта' name='mail' value='$mail'>
            <input class='pole' type='text' placeholder='Логин' name='login' value='$login'>
            <input class='pole' type='password' placeholder='Пароль' name='password' value='$password'>
           </div>
              <div class='levo'>
                        <div class='ysbox1'> 
                         <button class='btn' type='submit'>Сохранить</button>
                           <button class='btn' type='button' onclick='logout()'>Выход</button> 
                           </div>  
                            </div> 
                            <div class='levo'>
                            <div class='ysbox1'> 
                               <button class='btn' type='button' onclick='site()'>Настройки сайта</button>  
                               <button class='btn' type='button' onclick='adm_ys()'>Все услуги</button>      
                               <button class='btn' type='button' onclick='adm_ot()'>Отчет</button>                 
                            </div> 
                            </div>  
                              </form>

                         
                  "?>

    </div>


</div>


<div class="con0">
    <h3 class="t">Регистрация</h3>
    <div class='ys'>
        <form action="Aregister.php" method="post" class='ysp'>
            <div class="con1">
                <input class="pole" type="text" placeholder="Имя" name="n">
                <input class="pole" type="text" placeholder="Фамилия" name="n1">
                <input class="pole" type="text" placeholder="Логин" name="login">
                <input class="pole" type="text" placeholder="Пароль" name="pass">
                <input class="pole" type="text" placeholder="Повторите пароль" name="repeatpass">
                <input class="pole" type="text" placeholder="Почта" name="mail">
                </div>
                <div class='levo'>
                    <div class='ysbox1'>
                    <button class="btn" type="submit">Добавить</button>
                    </div>
                </div>

        </form>
    </div>
    <h3 class="t">Пользователи</h3>
    <?php
    global $conn;
    require_once('bd.php');
    session_start();
    $User = $_SESSION['User'];
    $sql = "SELECT * FROM user WHERE User <> '$User'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            echo "<div class='ys'>
    <form action='adm_p.php' method='post' class='ysp'>
        <div class='ysbox'>
            <input class='pole' type='text' placeholder='Имя' name='n' value='{$row['n']}'>
            <input class='pole' type='text' placeholder='Фамилия' name='n1' value='{$row['n1']}'>
            <input class='pole' type='text' placeholder='Почта' name='mail' value='{$row['mail']}'>
            <input class='pole' type='text' placeholder='Логин' name='login' value='{$row['login']}'>
            <input class='pole' type='password' placeholder='Пароль' name='password' value='{$row['password']}'>
            <input class='pole' type='text' placeholder='Администратор' name='adm' value='{$row['adm']}'>
        </div>
        <div class='levo'>
            <input type='hidden' name='User' value='{$row['User']}'>
            <button class='btn' type='submit'>Сохранить</button>
        </div>
    </form>
  <div class='ot'></div>
    <form action='adm_del.php' method='post'>
            <input type='hidden' name='User' value='{$row['User']}'>
            <button class='btn' type='submit' name='delete'>X</button>
    </form>

</div>
";


        }
    }
    ?>
</div>
<div class="m0"> </div>



<?php $content = ob_get_clean(); ?>

<?php require_once('base.php'); ?>



