<?php
global $name;
require_once('bd.php');

$title = $name;
ob_start();
?>
<div class="con0">
    <h3 class="t">Администратор</h3>
    <div class='ys'>

        <?php
        session_start();
        $User = $_SESSION['User'];
        $login = $_SESSION['login'];
        $password = $_SESSION['password'];
        $mail = $_SESSION['mail'];
        $n = $_SESSION['n'];
        $n1 = $_SESSION['n1'];
        echo "<form action='adm_p_o.php' method='post' class='ysp'>
            <div class='con1'>
            <input class='pole' type='text' placeholder='Имя' name='n' value='$n'>
            <input class='pole' type='text' placeholder='Фамилия' name='n1' value='$n1'>
            <input class='pole' type='text' placeholder='Почта' name='mail' value='$mail'>
            <input class='pole' type='text' placeholder='Логин' name='login' value='$login'>
            <input class='pole' type='password' placeholder='Пароль' name='password' value='$password'>
           </div>
              <div class='levo'>
                        <div class='ysbox1'> 
                         <button class='btn' type='submit'>Сохранить</button>
                           <button class='btn' type='button' onclick='logout()'>Выход</button> 
                           </div>  
                            </div> 
                            <div class='levo'>
                            <div class='ysbox1'> 
                               <button class='btn' type='button' onclick='site()'>Настройки сайта</button>  
                               <button class='btn' type='button' onclick='adm_ys0()'>Пользователи</button>      
                               <button class='btn' type='button' onclick='adm_ot()'>Отчет</button>                 
                            </div> 
                            </div>  
                              </form>

                         
                  "?>

    </div>


</div>


<div class="con0">
    <h3 class="t">Добавить услугу</h3>
    <div class='ys'>
        <form action="adnys.php" method="post" class='ysp' enctype="multipart/form-data">
            <div class="con1">
                <input class="pole" type="text" placeholder="Название" name="s_name">
                <textarea class="pole" placeholder="Описание" name="s_description" rows="4" cols="50"></textarea>
                <input class="pole" type="text" placeholder="Стоимость" name="s_cost">
                <input type="file" name="s_picture" accept="image/*">



            </div>
            <div class='levo'>
                <div class='ysbox1'>
                    <button class="btn" type="submit">Добавить</button>

                </div>
            </div>
        </form>
    </div>



    <h3 class="t">Услуги</h3>

    <?php
    global $conn;
    require_once('bd.php');

    $sql = "SELECT * FROM service";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            echo "<div class='ys'>

             <div class='con1'>
                     <form action='adm_y_s.php' method='post' enctype='multipart/form-data'>
                          <input class='pole' type='text' placeholder='Название' name='s_name' value={$row['s_name']}>
                          <textarea class='pole' placeholder='Описание' name='s_description' rows='4' cols='50' >{$row['s_description']}</textarea>
                          <input class='pole' type='text' placeholder='Стоимость' name='s_cost' value={$row['s_cost']}>
                          <input type='hidden' name='Ser' value='{$row['Ser']}'>
                          <input type='file' name='s_picture' accept='image/*' value='img/{$row['s_picture']}'>
                          <p></p>
                          <button class='btn' type='submit'>Сохранить</button>
                     </form>
             </div>
                 
                 
             <div class='levo'>
                <div class='ysbox1'>
                            <form action='az.php' method='post'>
                            <input type='hidden' name='s_Ser' value='{$row['Ser']}'>
                            <input type='hidden' name='s_cost' value='{$row['s_cost']}'>
                            <input type='hidden' name='s_name' value='{$row['s_name']}'>
                            <img src='img/{$row['s_picture']}' alt='Изображение' class='img' width='150' height='150'>
                            <p></p>                    
                            <div><button class='btn'>Заказать </button></div>
                            </form>
                     <form action='del_ysa.php' method='post'>
                         <input type='hidden' name='Ser' value='{$row['Ser']}'>
                         <button class='btn' type='submit'>Удалить услугу</button>
                    </form>
                </div>
             </div>


                
  
               
            </div>";

        }
    }
    ?>

<div class="m0"> </div>



<?php $content = ob_get_clean(); ?>

<?php require_once('base.php'); ?>



