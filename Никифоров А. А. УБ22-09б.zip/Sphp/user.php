<?php
global $name;
require_once('bd.php');

$title = $name;
ob_start();
?>
<div class="con0">
    <h3 class="t">Профиль</h3>
    <div class='ys'>

        <?php
session_start();
$User = $_SESSION['User'];
$login = $_SESSION['login'];
$password = $_SESSION['password'];
$mail = $_SESSION['mail'];
$n = $_SESSION['n'];
$n1 = $_SESSION['n1'];
        echo "<form action='user_p_o.php' method='post' class='ysp'>
            <div class='ysbox1'>
            <input class='pole' type='text' placeholder='Имя' name='n' value='$n'>
            <input class='pole' type='text' placeholder='Фамилия' name='n1' value='$n1'>
            <input class='pole' type='text' placeholder='Почта' name='mail' value='$mail'>
            <input class='pole' type='text' placeholder='Логин' name='login' value='$login'>
            <input class='pole' type='password' placeholder='Пароль' name='password' value='$password'>
          
            </div>   
        
                        <div class='levo'>
                        <div class='ysbox1'> 
                        <button class='btn' type='button' onclick='logout()'>Выход</button>  
                          <button class='btn' type='submit'>Сохранить</button>
                        <button class='btn' type='button' onclick='user_ys()'>История услуг</button> 
                          </div> 
                            </div> 
                                </form>
                  "?>

        </div>


    </div>


<div class="con0">
    <h3 class="t">Услуги</h3>

    <?php
    global $conn;
    require_once('bd.php');

    $sql = "SELECT * FROM service";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            echo "<div class='ys'>
                <div class='ysbox'>
                    <p>{$row['s_name']}</p>
                    <p>{$row['s_description']} </p>
                    <p>Стоимость: {$row['s_cost']}</p>
                    <form action='z.php' method='post'>
                    <input type='hidden' name='s_Ser' value='{$row['Ser']}'>
                    <input type='hidden' name='s_cost' value='{$row['s_cost']}'>
                    <input type='hidden' name='s_name' value='{$row['s_name']}'>
                    <div><button class='btn'>Заказать </button></div>
                    </form>
                </div>";

            echo "<div class='ysbox'>
                <div class='levo'>
   <img src='img/{$row['s_picture']}' alt='Изображение' class='img' width='150' height='150'>
                </div>
            </div>";

            echo "</div>";
        }
    }
    ?>
</div>
<div class="m0"> </div>



<?php $content = ob_get_clean(); ?>

<?php require_once('base.php'); ?>



