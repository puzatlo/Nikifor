<?php
global $conn;
require_once('bd.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $User = $_SESSION['User'];
    $n = $_POST['n'];
    $n1 = $_POST['n1'];
    $mail = $_POST['mail'];
    $login = $_POST['login'];
    $password = $_POST['password'];

    // Здесь вам нужно выполнить SQL-запрос для обновления записи в таблице "Полные тексты"
    $sql = "UPDATE user SET n = '$n', n1 = '$n1', mail = '$mail', login = '$login', password = '$password' WHERE User = '$User'";
    // Выполнение запроса
    $result = mysqli_query($conn, $sql);
    session_start();
    $_SESSION['User'] = $User;
    $_SESSION['login'] =  $login;
    $_SESSION['password'] = $password;
    $_SESSION['mail']  = $mail;
    $_SESSION['n'] = $n;
    $_SESSION['n1']  = $n1;
    echo "<script>window.location.href = 'user.php';</script>";

}
