<?php
ob_start();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo isset($title) ? $title : ''; ?></title>
    <style>
        <?php
    global $conn;
    require_once('bd.php');

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL-запрос для извлечения значения цвета
$sql = "SELECT * FROM site WHERE id = 1"; // Предполагаем, что у вас есть таблица с именем your_color_table и столбцом color_value
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $color = $row["color"];
}

?>
        :root {
            --main-bg-color: <?php  echo $color; ?>;
            --ww: #f5f5f7;
            --ser: #6e6e73;
        }
        html{
            min-height: 100%;
        }
        body {
            min-height: 100%;
            font-family: 'Open Sans', sans-serif;
            background-color: var(--ww);
        }
        /* Стили для модального окна */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }
        .modal-content {
            background-color: rgba(255, 255, 255, 0.8);
            -webkit-backdrop-filter: blur(5px);
            backdrop-filter: blur(2px);
            margin: 15% auto;
            padding: 20px;
            border: 0px solid #888;
            border-radius: 5px;
            width: 50%;
            text-align: center;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .t {
            color: var(--ser);
        }
        .t:hover{
            color: var(--main-bg-color);
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 65px;
            width: 100%;
            top: 0;
            position: fixed;
            -webkit-backdrop-filter: blur(5px);
            backdrop-filter: blur(2px);
            box-shadow: 0px 2px 10px rgba(27,28,28, 0.2);
            transition: box-shadow 0.3s;
            z-index: 9999;
        }
        .header:hover {
            box-shadow: 0px 2px 10px rgba(27,28,28, 0.5);
        }
        .f{

            display: flex;
            justify-content: center;
            align-items: end;
            text-align: center; /* Для центрирования текста по горизонтали */
            height: 100%;
            width: 100%;
            transition: background 0.9s; /* Для плавного перехода */
        }
        .f:hover  {
            -webkit-backdrop-filter: blur(5px);
            backdrop-filter: blur(2px);
        }
        .v0{
        margin: 0px;
        margin-left: -8px;
        margin-right: -8px;
        height: 100%;
        }
        .m0{
              height: 50vh;
          }
        .h0{
         height: 65px;
         width: 100%;
        }

        .con{
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            height: 100%;
        }
        .con0 {
            width: 70%;

        }
        .con1{
            display: flex;
            justify-content: center;
            flex-direction: column;
            padding: 0px 0px 0px 0px;
            width: 100%;

        }
        .btn {
            width: 100%;
            font-family: 'Open Sans', sans-serif;
            display: inline-block;
            padding: 10px 20px;
            background-color: var(--main-bg-color);
            color: var(--ww);
            text-align: center;
            text-decoration: none;
            border: 0px solid var(--main-bg-color);
            border-radius: 5px;
            cursor: pointer;
            Margin-bottom: 10px;
            transition: transform 0.3s, box-shadow 0.3s; /* Добавлены свойства перехода */
            box-shadow: 0px 2px 10px rgba(27,28,28, 0.2);
        }
        .btn:hover {
            transform: scale(1.003);
            box-shadow: 0px 2px 10px rgba(27,28,28, 0.5);
        }
        .btn {
            width: 100%;
            font-family: 'Open Sans', sans-serif;
            display: inline-block;
            padding: 10px 20px;
            background-color: var(--main-bg-color);
            color: var(--ww);
            text-align: center;
            text-decoration: none;
            border: 0px solid var(--main-bg-color);
            border-radius: 5px;
            cursor: pointer;
            Margin-bottom: 10px;
            transition: transform 0.3s, box-shadow 0.3s; /* Добавлены свойства перехода */
            box-shadow: 0px 2px 10px rgba(27,28,28, 0.2);
        }
        .btn:hover {
            transform: scale(1.003);
            box-shadow: 0px 2px 10px rgba(27,28,28, 0.5);
        }
        .pole{
            border: 1px solid var(--main-bg-color);
            background-color: var(--ww);
            border-radius: 5px;
            width: 300px;
            height: 30px;
            font-family: 'Open Sans', sans-serif;
            Margin-bottom: 10px;
            transition: transform 0.3s, box-shadow 0.3s; /* Добавлены свойства перехода */
            box-shadow: 0px 2px 10px rgba(27,28,28, 0.2);
        }
        .pole:hover {
            transform: scale(1.003);
            box-shadow: 0px 2px 10px rgba(27,28,28, 0.5);
        }
        .ysp{
            display: flex;
            align-items: center;
            justify-content: flex-start;
            width: 100%;
            position: relative;
        }
        .ys{
            background-color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            padding: 20px;
            width: 100%;
            border: 1px black;
            border-radius: 5px;
            margin-bottom: 20px;
            transition: transform 0.3s, box-shadow 0.3s;
            box-shadow: 0px 2px 10px rgba(27,28,28, 0.2);
            position: relative;
        }
        .ys:hover {
            transform: scale(1.003);
            box-shadow: 0px 2px 10px rgba(27,28,28, 0.5);
        }
        .ys .ysbox {
            margin-right: 20px;
            width: 100vh;
        }
        .ysbox1 {
            margin-right: 20px;

        }
        .img {
            border-radius: 5px;
        }
        .levo{
            width: 100%;
            text-align: right;
            margin-left: 20px;
        }
        .n{
            border: 0px solid var(--main-bg-color);
            background-color: #ffffff;
            color: #ffffff;
            font-family: 'Open Sans', sans-serif;
            pointer-events: none;
            user-select: none;
        }
        .grid-container {
            display: grid;
            grid-template-columns: 1fr auto;
            grid-template-rows: auto 1fr;
            gap: 10px;
        }

        .left-container {
            grid-row: span 2;
        }

        .top-right-container {
            grid-column: 2;
        }

        .bottom-right-container {
            grid-column: 2;
            grid-row: 2;
        }
        .ot{
            margin: 5px;
        }

    </style>
</head>
<body>
<div class="v0">


<!--header-->

<div class="header">
    <?php
    global $logo;
    global $name;
    require_once('bd.php');

    echo "<img src='img/{$logo}' alt='Изображение' class='img' width='45' height='45'>";
    echo '<h4>'. $name .'</h4>'
    ?>
</div>
    <div class="h0"></div>
<!--content-->
    <div class="con">
<?php echo isset($content) ? $content : ''; ?>
</div>
<!--footer-->
    <div class="f">
        &copy; <span id="currentYear"></span>
        <?php
        global $logo;
        global $name;
        require_once('bd.php');
        echo "<img src='img/{$logo}' alt='Изображение' class='img' width='45' height='45'>";
        ?>

    </div>
</div>
<script>
    document.getElementById("currentYear").innerText = new Date().getFullYear();

    function register() {
        document.getElementById("loginForm").action = "reg.php";
        document.getElementById("loginForm").submit();
    }
    function reg() {
        document.getElementById("regForm").action = "index.php";
        document.getElementById("regForm").submit();
    }

    document.addEventListener("DOMContentLoaded", function() {
        var modal = document.getElementById("myModal");

        // Открытие модального окна при клике на соответствующую кнопку "Заказать"
        var openModalButtons = document.querySelectorAll(".openModalBtn");
        openModalButtons.forEach(function(button) {
            button.addEventListener("click", function() {
                modal.style.display = "block";
            });
        });

        // Закрытие модального окна при клике вне его области
        window.addEventListener("click", function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        });

    });
    function logout() {
        window.location.href = 'index.php';
    }
    function user_ys() {
        window.location.href = 'user_ys.php';
    }
    function user_ys0() {
        window.location.href = 'user.php';
    }
    function adm_ys() {
        window.location.href = 'adm_ys.php';
    }
    function adm_ys0() {
        window.location.href = 'adm.php';
    }
    function adm_ot() {
        window.location.href = 'adm_ot.php';
    }
    function adm_ot0() {
        window.location.href = 'adm.php';
    }
    function site() {
        window.location.href = 'site.php';
    }
    function site0() {
        window.location.href = 'adm.php';
    }
</script>
</body>
</html>
