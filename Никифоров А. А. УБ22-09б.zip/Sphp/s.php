<?php
global $conn;
require_once('bd.php');

$name = $_POST['name'];
$description = $_POST['description'];
$color = $_POST['color'];

// Проверяем, был ли загружен файл
if (!empty($_FILES['logo']['name'])) {
    $uploadDir = 'img/';

    // Генерируем уникальное имя для файла
    $fileName = uniqid() . '_' . basename($_FILES['logo']['name']);

    $targetFilePath = $uploadDir . $fileName;

    // Перемещаем загруженный файл в указанную директорию
    if (move_uploaded_file($_FILES['logo']['tmp_name'], $targetFilePath)) {
        $logo = $fileName;

        // Вставляем данные в базу данных
        $sql = "UPDATE site SET name = '$name', description = '$description', logo = '$logo',color = '$color' WHERE ID = 1";
        if ($conn->query($sql) === TRUE) {
            echo "<script>window.location.href = 'site.php';</script>";
        } else {
            echo "Ошибка при выполнении запроса: " . $conn->error;
        }
    } else {
        echo "Ошибка при загрузке файла.";
    }
} else {
    echo "Загрузите файл.";
}
