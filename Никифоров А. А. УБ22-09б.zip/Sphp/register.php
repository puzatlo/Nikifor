<?php
global $conn;
require_once('bd.php');
$n = $_POST['n'];
$n1 = $_POST['n1'];
$login = $_POST['login'];
$pass = $_POST['pass'];
$repeatpass = $_POST['repeatpass'];
$email = $_POST['mail'];

if (empty($login) || empty($pass) || empty($repeatpass) || empty($email)) {
    echo "Заполните все поля";
} else {
    if ($pass != $repeatpass) {
        echo "Пароли не совпадают";
    } else {

        $sql = "INSERT INTO `user` (login, password, mail, n, n1) VALUES ('$login', '$pass', '$email', '$n', '$n1')";
        if ($conn->query($sql) === TRUE) {

            echo "<script>window.location.href = 'index.php';</script>";
        } else {
            echo "<script>window.location.href = 'register.php';</script>";
        }
    }
}
?>
