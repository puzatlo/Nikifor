<?php
global $conn;
require_once('bd.php');

$s_name = $_POST['s_name'];
$s_description = $_POST['s_description'];
$s_cost = $_POST['s_cost'];
$Ser = $_POST['Ser'];

// Проверяем, был ли загружен файл
if (!empty($_FILES['s_picture']['name'])) {
    $uploadDir = 'img/';

    // Генерируем уникальное имя для файла
    $fileName = uniqid() . '_' . basename($_FILES['s_picture']['name']);

    $targetFilePath = $uploadDir . $fileName;

    // Перемещаем загруженный файл в указанную директорию
    if (move_uploaded_file($_FILES['s_picture']['tmp_name'], $targetFilePath)) {
        $s_picture = $fileName;

        // Вставляем данные в базу данных
        $sql = "UPDATE service SET s_cost = '$s_cost', s_description = '$s_description', s_name = '$s_name', s_picture = '$s_picture' WHERE Ser = '$Ser'";
        if ($conn->query($sql) === TRUE) {
            echo "<script>window.location.href = 'adm_ys.php';</script>";
        } else {
            echo "Ошибка при выполнении запроса: " . $conn->error;
        }
    } else {
        echo "Ошибка при загрузке файла.";
    }
} else {
    echo "Загрузите файл.";
}
